﻿namespace AbilityStone
{
    partial class Form1
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.FirstDrilling = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.FirstBtn1 = new System.Windows.Forms.Button();
            this.FirstBtn9 = new System.Windows.Forms.Button();
            this.FirstBtn8 = new System.Windows.Forms.Button();
            this.FirstBtn7 = new System.Windows.Forms.Button();
            this.FirstBtn6 = new System.Windows.Forms.Button();
            this.FirstBtn5 = new System.Windows.Forms.Button();
            this.FirstBtn4 = new System.Windows.Forms.Button();
            this.FirstBtn2 = new System.Windows.Forms.Button();
            this.FirstBtn3 = new System.Windows.Forms.Button();
            this.SecondBtn9 = new System.Windows.Forms.Button();
            this.SecondBtn2 = new System.Windows.Forms.Button();
            this.SecondBtn1 = new System.Windows.Forms.Button();
            this.SecondBtn3 = new System.Windows.Forms.Button();
            this.SecondBtn4 = new System.Windows.Forms.Button();
            this.SecondBtn5 = new System.Windows.Forms.Button();
            this.SecondBtn6 = new System.Windows.Forms.Button();
            this.SecondBtn7 = new System.Windows.Forms.Button();
            this.SecondBtn8 = new System.Windows.Forms.Button();
            this.SecondBtn0 = new System.Windows.Forms.Button();
            this.secondDrilling = new System.Windows.Forms.Button();
            this.thirdDrilling = new System.Windows.Forms.Button();
            this.ThirdBtn9 = new System.Windows.Forms.Button();
            this.ThirdBtn2 = new System.Windows.Forms.Button();
            this.ThirdBtn1 = new System.Windows.Forms.Button();
            this.ThirdBtn3 = new System.Windows.Forms.Button();
            this.ThirdBtn4 = new System.Windows.Forms.Button();
            this.ThirdBtn5 = new System.Windows.Forms.Button();
            this.ThirdBtn6 = new System.Windows.Forms.Button();
            this.ThirdBtn7 = new System.Windows.Forms.Button();
            this.ThirdBtn8 = new System.Windows.Forms.Button();
            this.ThirdBtn0 = new System.Windows.Forms.Button();
            this.button36 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.problabel = new System.Windows.Forms.Label();
            this.FirstBtn0 = new System.Windows.Forms.Button();
            this.firstSucessLabel = new System.Windows.Forms.Label();
            this.thirdSucessLabel = new System.Windows.Forms.Label();
            this.secondSucessLabel = new System.Windows.Forms.Label();
            this.reset = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // FirstDrilling
            // 
            this.FirstDrilling.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.FirstDrilling.Cursor = System.Windows.Forms.Cursors.Hand;
            this.FirstDrilling.Font = new System.Drawing.Font("돋움", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.FirstDrilling.Location = new System.Drawing.Point(864, 87);
            this.FirstDrilling.Name = "FirstDrilling";
            this.FirstDrilling.Size = new System.Drawing.Size(130, 90);
            this.FirstDrilling.TabIndex = 0;
            this.FirstDrilling.Text = "세공";
            this.FirstDrilling.UseVisualStyleBackColor = false;
            this.FirstDrilling.Click += new System.EventHandler(this.FirstDrilling_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("맑은 고딕", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.label1.Location = new System.Drawing.Point(12, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(139, 38);
            this.label1.TabIndex = 1;
            this.label1.Text = "증가 능력";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("맑은 고딕", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label2.ForeColor = System.Drawing.Color.Red;
            this.label2.Location = new System.Drawing.Point(12, 345);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(139, 38);
            this.label2.TabIndex = 2;
            this.label2.Text = "감소 능력";
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.button2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button2.Font = new System.Drawing.Font("돋움", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button2.Location = new System.Drawing.Point(34, 225);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(90, 90);
            this.button2.TabIndex = 3;
            this.button2.Text = "B";
            this.button2.UseVisualStyleBackColor = false;
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.button3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button3.Font = new System.Drawing.Font("돋움", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button3.Location = new System.Drawing.Point(34, 82);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(90, 90);
            this.button3.TabIndex = 4;
            this.button3.Text = "A";
            this.button3.UseVisualStyleBackColor = false;
            // 
            // FirstBtn1
            // 
            this.FirstBtn1.BackColor = System.Drawing.Color.Black;
            this.FirstBtn1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.FirstBtn1.Font = new System.Drawing.Font("돋움", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.FirstBtn1.Location = new System.Drawing.Point(231, 132);
            this.FirstBtn1.Name = "FirstBtn1";
            this.FirstBtn1.Size = new System.Drawing.Size(40, 40);
            this.FirstBtn1.TabIndex = 5;
            this.FirstBtn1.UseVisualStyleBackColor = false;
            // 
            // FirstBtn9
            // 
            this.FirstBtn9.BackColor = System.Drawing.Color.Black;
            this.FirstBtn9.Cursor = System.Windows.Forms.Cursors.Hand;
            this.FirstBtn9.Font = new System.Drawing.Font("돋움", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.FirstBtn9.Location = new System.Drawing.Point(791, 132);
            this.FirstBtn9.Name = "FirstBtn9";
            this.FirstBtn9.Size = new System.Drawing.Size(40, 40);
            this.FirstBtn9.TabIndex = 6;
            this.FirstBtn9.UseVisualStyleBackColor = false;
            // 
            // FirstBtn8
            // 
            this.FirstBtn8.BackColor = System.Drawing.Color.Black;
            this.FirstBtn8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.FirstBtn8.Font = new System.Drawing.Font("돋움", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.FirstBtn8.Location = new System.Drawing.Point(721, 132);
            this.FirstBtn8.Name = "FirstBtn8";
            this.FirstBtn8.Size = new System.Drawing.Size(40, 40);
            this.FirstBtn8.TabIndex = 7;
            this.FirstBtn8.UseVisualStyleBackColor = false;
            // 
            // FirstBtn7
            // 
            this.FirstBtn7.BackColor = System.Drawing.Color.Black;
            this.FirstBtn7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.FirstBtn7.Font = new System.Drawing.Font("돋움", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.FirstBtn7.Location = new System.Drawing.Point(651, 132);
            this.FirstBtn7.Name = "FirstBtn7";
            this.FirstBtn7.Size = new System.Drawing.Size(40, 40);
            this.FirstBtn7.TabIndex = 8;
            this.FirstBtn7.UseVisualStyleBackColor = false;
            // 
            // FirstBtn6
            // 
            this.FirstBtn6.BackColor = System.Drawing.Color.Black;
            this.FirstBtn6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.FirstBtn6.Font = new System.Drawing.Font("돋움", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.FirstBtn6.Location = new System.Drawing.Point(581, 132);
            this.FirstBtn6.Name = "FirstBtn6";
            this.FirstBtn6.Size = new System.Drawing.Size(40, 40);
            this.FirstBtn6.TabIndex = 9;
            this.FirstBtn6.UseVisualStyleBackColor = false;
            // 
            // FirstBtn5
            // 
            this.FirstBtn5.BackColor = System.Drawing.Color.Black;
            this.FirstBtn5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.FirstBtn5.Font = new System.Drawing.Font("돋움", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.FirstBtn5.Location = new System.Drawing.Point(511, 132);
            this.FirstBtn5.Name = "FirstBtn5";
            this.FirstBtn5.Size = new System.Drawing.Size(40, 40);
            this.FirstBtn5.TabIndex = 10;
            this.FirstBtn5.UseVisualStyleBackColor = false;
            // 
            // FirstBtn4
            // 
            this.FirstBtn4.BackColor = System.Drawing.Color.Black;
            this.FirstBtn4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.FirstBtn4.Font = new System.Drawing.Font("돋움", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.FirstBtn4.Location = new System.Drawing.Point(441, 132);
            this.FirstBtn4.Name = "FirstBtn4";
            this.FirstBtn4.Size = new System.Drawing.Size(40, 40);
            this.FirstBtn4.TabIndex = 11;
            this.FirstBtn4.UseVisualStyleBackColor = false;
            // 
            // FirstBtn2
            // 
            this.FirstBtn2.BackColor = System.Drawing.Color.Black;
            this.FirstBtn2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.FirstBtn2.Font = new System.Drawing.Font("돋움", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.FirstBtn2.Location = new System.Drawing.Point(301, 132);
            this.FirstBtn2.Name = "FirstBtn2";
            this.FirstBtn2.Size = new System.Drawing.Size(40, 40);
            this.FirstBtn2.TabIndex = 12;
            this.FirstBtn2.UseVisualStyleBackColor = false;
            // 
            // FirstBtn3
            // 
            this.FirstBtn3.BackColor = System.Drawing.Color.Black;
            this.FirstBtn3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.FirstBtn3.Font = new System.Drawing.Font("돋움", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.FirstBtn3.Location = new System.Drawing.Point(371, 132);
            this.FirstBtn3.Name = "FirstBtn3";
            this.FirstBtn3.Size = new System.Drawing.Size(40, 40);
            this.FirstBtn3.TabIndex = 13;
            this.FirstBtn3.UseVisualStyleBackColor = false;
            // 
            // SecondBtn9
            // 
            this.SecondBtn9.BackColor = System.Drawing.Color.Black;
            this.SecondBtn9.Cursor = System.Windows.Forms.Cursors.Hand;
            this.SecondBtn9.Font = new System.Drawing.Font("돋움", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.SecondBtn9.Location = new System.Drawing.Point(791, 275);
            this.SecondBtn9.Name = "SecondBtn9";
            this.SecondBtn9.Size = new System.Drawing.Size(40, 40);
            this.SecondBtn9.TabIndex = 24;
            this.SecondBtn9.UseVisualStyleBackColor = false;
            // 
            // SecondBtn2
            // 
            this.SecondBtn2.BackColor = System.Drawing.Color.Black;
            this.SecondBtn2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.SecondBtn2.Font = new System.Drawing.Font("돋움", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.SecondBtn2.Location = new System.Drawing.Point(301, 275);
            this.SecondBtn2.Name = "SecondBtn2";
            this.SecondBtn2.Size = new System.Drawing.Size(40, 40);
            this.SecondBtn2.TabIndex = 23;
            this.SecondBtn2.UseVisualStyleBackColor = false;
            // 
            // SecondBtn1
            // 
            this.SecondBtn1.BackColor = System.Drawing.Color.Black;
            this.SecondBtn1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.SecondBtn1.Font = new System.Drawing.Font("돋움", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.SecondBtn1.Location = new System.Drawing.Point(231, 275);
            this.SecondBtn1.Name = "SecondBtn1";
            this.SecondBtn1.Size = new System.Drawing.Size(40, 40);
            this.SecondBtn1.TabIndex = 22;
            this.SecondBtn1.UseVisualStyleBackColor = false;
            // 
            // SecondBtn3
            // 
            this.SecondBtn3.BackColor = System.Drawing.Color.Black;
            this.SecondBtn3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.SecondBtn3.Font = new System.Drawing.Font("돋움", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.SecondBtn3.Location = new System.Drawing.Point(371, 275);
            this.SecondBtn3.Name = "SecondBtn3";
            this.SecondBtn3.Size = new System.Drawing.Size(40, 40);
            this.SecondBtn3.TabIndex = 21;
            this.SecondBtn3.UseVisualStyleBackColor = false;
            // 
            // SecondBtn4
            // 
            this.SecondBtn4.BackColor = System.Drawing.Color.Black;
            this.SecondBtn4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.SecondBtn4.Font = new System.Drawing.Font("돋움", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.SecondBtn4.Location = new System.Drawing.Point(441, 275);
            this.SecondBtn4.Name = "SecondBtn4";
            this.SecondBtn4.Size = new System.Drawing.Size(40, 40);
            this.SecondBtn4.TabIndex = 20;
            this.SecondBtn4.UseVisualStyleBackColor = false;
            // 
            // SecondBtn5
            // 
            this.SecondBtn5.BackColor = System.Drawing.Color.Black;
            this.SecondBtn5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.SecondBtn5.Font = new System.Drawing.Font("돋움", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.SecondBtn5.Location = new System.Drawing.Point(511, 275);
            this.SecondBtn5.Name = "SecondBtn5";
            this.SecondBtn5.Size = new System.Drawing.Size(40, 40);
            this.SecondBtn5.TabIndex = 19;
            this.SecondBtn5.UseVisualStyleBackColor = false;
            // 
            // SecondBtn6
            // 
            this.SecondBtn6.BackColor = System.Drawing.Color.Black;
            this.SecondBtn6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.SecondBtn6.Font = new System.Drawing.Font("돋움", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.SecondBtn6.Location = new System.Drawing.Point(581, 275);
            this.SecondBtn6.Name = "SecondBtn6";
            this.SecondBtn6.Size = new System.Drawing.Size(40, 40);
            this.SecondBtn6.TabIndex = 18;
            this.SecondBtn6.UseVisualStyleBackColor = false;
            // 
            // SecondBtn7
            // 
            this.SecondBtn7.BackColor = System.Drawing.Color.Black;
            this.SecondBtn7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.SecondBtn7.Font = new System.Drawing.Font("돋움", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.SecondBtn7.Location = new System.Drawing.Point(651, 275);
            this.SecondBtn7.Name = "SecondBtn7";
            this.SecondBtn7.Size = new System.Drawing.Size(40, 40);
            this.SecondBtn7.TabIndex = 17;
            this.SecondBtn7.UseVisualStyleBackColor = false;
            // 
            // SecondBtn8
            // 
            this.SecondBtn8.BackColor = System.Drawing.Color.Black;
            this.SecondBtn8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.SecondBtn8.Font = new System.Drawing.Font("돋움", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.SecondBtn8.Location = new System.Drawing.Point(721, 275);
            this.SecondBtn8.Name = "SecondBtn8";
            this.SecondBtn8.Size = new System.Drawing.Size(40, 40);
            this.SecondBtn8.TabIndex = 16;
            this.SecondBtn8.UseVisualStyleBackColor = false;
            // 
            // SecondBtn0
            // 
            this.SecondBtn0.BackColor = System.Drawing.Color.Black;
            this.SecondBtn0.Cursor = System.Windows.Forms.Cursors.Hand;
            this.SecondBtn0.Font = new System.Drawing.Font("돋움", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.SecondBtn0.Location = new System.Drawing.Point(161, 275);
            this.SecondBtn0.Name = "SecondBtn0";
            this.SecondBtn0.Size = new System.Drawing.Size(40, 40);
            this.SecondBtn0.TabIndex = 15;
            this.SecondBtn0.UseVisualStyleBackColor = false;
            // 
            // secondDrilling
            // 
            this.secondDrilling.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.secondDrilling.Cursor = System.Windows.Forms.Cursors.Hand;
            this.secondDrilling.Font = new System.Drawing.Font("돋움", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.secondDrilling.Location = new System.Drawing.Point(864, 230);
            this.secondDrilling.Name = "secondDrilling";
            this.secondDrilling.Size = new System.Drawing.Size(130, 90);
            this.secondDrilling.TabIndex = 25;
            this.secondDrilling.Text = "세공";
            this.secondDrilling.UseVisualStyleBackColor = false;
            this.secondDrilling.Click += new System.EventHandler(this.SecondDrilling_Click);
            // 
            // thirdDrilling
            // 
            this.thirdDrilling.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.thirdDrilling.Cursor = System.Windows.Forms.Cursors.Hand;
            this.thirdDrilling.Font = new System.Drawing.Font("돋움", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.thirdDrilling.Location = new System.Drawing.Point(864, 413);
            this.thirdDrilling.Name = "thirdDrilling";
            this.thirdDrilling.Size = new System.Drawing.Size(130, 90);
            this.thirdDrilling.TabIndex = 37;
            this.thirdDrilling.Text = "세공";
            this.thirdDrilling.UseVisualStyleBackColor = false;
            this.thirdDrilling.Click += new System.EventHandler(this.ThirdDrilling_Click);
            // 
            // ThirdBtn9
            // 
            this.ThirdBtn9.BackColor = System.Drawing.Color.Black;
            this.ThirdBtn9.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ThirdBtn9.Font = new System.Drawing.Font("돋움", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.ThirdBtn9.Location = new System.Drawing.Point(791, 458);
            this.ThirdBtn9.Name = "ThirdBtn9";
            this.ThirdBtn9.Size = new System.Drawing.Size(40, 40);
            this.ThirdBtn9.TabIndex = 36;
            this.ThirdBtn9.UseVisualStyleBackColor = false;
            // 
            // ThirdBtn2
            // 
            this.ThirdBtn2.BackColor = System.Drawing.Color.Black;
            this.ThirdBtn2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ThirdBtn2.Font = new System.Drawing.Font("돋움", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.ThirdBtn2.Location = new System.Drawing.Point(301, 458);
            this.ThirdBtn2.Name = "ThirdBtn2";
            this.ThirdBtn2.Size = new System.Drawing.Size(40, 40);
            this.ThirdBtn2.TabIndex = 35;
            this.ThirdBtn2.UseVisualStyleBackColor = false;
            // 
            // ThirdBtn1
            // 
            this.ThirdBtn1.BackColor = System.Drawing.Color.Black;
            this.ThirdBtn1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ThirdBtn1.Font = new System.Drawing.Font("돋움", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.ThirdBtn1.Location = new System.Drawing.Point(231, 458);
            this.ThirdBtn1.Name = "ThirdBtn1";
            this.ThirdBtn1.Size = new System.Drawing.Size(40, 40);
            this.ThirdBtn1.TabIndex = 34;
            this.ThirdBtn1.UseVisualStyleBackColor = false;
            // 
            // ThirdBtn3
            // 
            this.ThirdBtn3.BackColor = System.Drawing.Color.Black;
            this.ThirdBtn3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ThirdBtn3.Font = new System.Drawing.Font("돋움", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.ThirdBtn3.Location = new System.Drawing.Point(371, 458);
            this.ThirdBtn3.Name = "ThirdBtn3";
            this.ThirdBtn3.Size = new System.Drawing.Size(40, 40);
            this.ThirdBtn3.TabIndex = 33;
            this.ThirdBtn3.UseVisualStyleBackColor = false;
            // 
            // ThirdBtn4
            // 
            this.ThirdBtn4.BackColor = System.Drawing.Color.Black;
            this.ThirdBtn4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ThirdBtn4.Font = new System.Drawing.Font("돋움", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.ThirdBtn4.Location = new System.Drawing.Point(441, 458);
            this.ThirdBtn4.Name = "ThirdBtn4";
            this.ThirdBtn4.Size = new System.Drawing.Size(40, 40);
            this.ThirdBtn4.TabIndex = 32;
            this.ThirdBtn4.UseVisualStyleBackColor = false;
            // 
            // ThirdBtn5
            // 
            this.ThirdBtn5.BackColor = System.Drawing.Color.Black;
            this.ThirdBtn5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ThirdBtn5.Font = new System.Drawing.Font("돋움", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.ThirdBtn5.Location = new System.Drawing.Point(511, 458);
            this.ThirdBtn5.Name = "ThirdBtn5";
            this.ThirdBtn5.Size = new System.Drawing.Size(40, 40);
            this.ThirdBtn5.TabIndex = 31;
            this.ThirdBtn5.UseVisualStyleBackColor = false;
            // 
            // ThirdBtn6
            // 
            this.ThirdBtn6.BackColor = System.Drawing.Color.Black;
            this.ThirdBtn6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ThirdBtn6.Font = new System.Drawing.Font("돋움", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.ThirdBtn6.Location = new System.Drawing.Point(581, 458);
            this.ThirdBtn6.Name = "ThirdBtn6";
            this.ThirdBtn6.Size = new System.Drawing.Size(40, 40);
            this.ThirdBtn6.TabIndex = 30;
            this.ThirdBtn6.UseVisualStyleBackColor = false;
            // 
            // ThirdBtn7
            // 
            this.ThirdBtn7.BackColor = System.Drawing.Color.Black;
            this.ThirdBtn7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ThirdBtn7.Font = new System.Drawing.Font("돋움", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.ThirdBtn7.Location = new System.Drawing.Point(651, 458);
            this.ThirdBtn7.Name = "ThirdBtn7";
            this.ThirdBtn7.Size = new System.Drawing.Size(40, 40);
            this.ThirdBtn7.TabIndex = 29;
            this.ThirdBtn7.UseVisualStyleBackColor = false;
            // 
            // ThirdBtn8
            // 
            this.ThirdBtn8.BackColor = System.Drawing.Color.Black;
            this.ThirdBtn8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ThirdBtn8.Font = new System.Drawing.Font("돋움", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.ThirdBtn8.Location = new System.Drawing.Point(721, 458);
            this.ThirdBtn8.Name = "ThirdBtn8";
            this.ThirdBtn8.Size = new System.Drawing.Size(40, 40);
            this.ThirdBtn8.TabIndex = 28;
            this.ThirdBtn8.UseVisualStyleBackColor = false;
            // 
            // ThirdBtn0
            // 
            this.ThirdBtn0.BackColor = System.Drawing.Color.Black;
            this.ThirdBtn0.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ThirdBtn0.Font = new System.Drawing.Font("돋움", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.ThirdBtn0.Location = new System.Drawing.Point(161, 458);
            this.ThirdBtn0.Name = "ThirdBtn0";
            this.ThirdBtn0.Size = new System.Drawing.Size(40, 40);
            this.ThirdBtn0.TabIndex = 27;
            this.ThirdBtn0.UseVisualStyleBackColor = false;
            // 
            // button36
            // 
            this.button36.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.button36.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button36.Font = new System.Drawing.Font("돋움", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button36.Location = new System.Drawing.Point(34, 408);
            this.button36.Name = "button36";
            this.button36.Size = new System.Drawing.Size(90, 90);
            this.button36.TabIndex = 26;
            this.button36.Text = "C";
            this.button36.UseVisualStyleBackColor = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("맑은 고딕", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label3.Location = new System.Drawing.Point(763, 18);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(155, 38);
            this.label3.TabIndex = 38;
            this.label3.Text = "성공 확률 :";
            // 
            // problabel
            // 
            this.problabel.AutoSize = true;
            this.problabel.Font = new System.Drawing.Font("맑은 고딕", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.problabel.Location = new System.Drawing.Point(924, 18);
            this.problabel.Name = "problabel";
            this.problabel.Size = new System.Drawing.Size(70, 38);
            this.problabel.TabIndex = 39;
            this.problabel.Text = "75%";
            this.problabel.Click += new System.EventHandler(this.label4_Click);
            // 
            // FirstBtn0
            // 
            this.FirstBtn0.BackColor = System.Drawing.Color.Black;
            this.FirstBtn0.Cursor = System.Windows.Forms.Cursors.Hand;
            this.FirstBtn0.Font = new System.Drawing.Font("돋움", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.FirstBtn0.Location = new System.Drawing.Point(161, 132);
            this.FirstBtn0.Name = "FirstBtn0";
            this.FirstBtn0.Size = new System.Drawing.Size(40, 40);
            this.FirstBtn0.TabIndex = 40;
            this.FirstBtn0.UseVisualStyleBackColor = false;
            this.FirstBtn0.Click += new System.EventHandler(this.FirstBtn0_Click);
            // 
            // firstSucessLabel
            // 
            this.firstSucessLabel.AutoSize = true;
            this.firstSucessLabel.BackColor = System.Drawing.Color.Transparent;
            this.firstSucessLabel.Font = new System.Drawing.Font("맑은 고딕", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.firstSucessLabel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.firstSucessLabel.Location = new System.Drawing.Point(130, 82);
            this.firstSucessLabel.Name = "firstSucessLabel";
            this.firstSucessLabel.Size = new System.Drawing.Size(58, 38);
            this.firstSucessLabel.TabIndex = 41;
            this.firstSucessLabel.Text = "x 0";
            // 
            // thirdSucessLabel
            // 
            this.thirdSucessLabel.AutoSize = true;
            this.thirdSucessLabel.BackColor = System.Drawing.Color.Transparent;
            this.thirdSucessLabel.Font = new System.Drawing.Font("맑은 고딕", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.thirdSucessLabel.ForeColor = System.Drawing.Color.Red;
            this.thirdSucessLabel.Location = new System.Drawing.Point(130, 408);
            this.thirdSucessLabel.Name = "thirdSucessLabel";
            this.thirdSucessLabel.Size = new System.Drawing.Size(58, 38);
            this.thirdSucessLabel.TabIndex = 42;
            this.thirdSucessLabel.Text = "x 0";
            // 
            // secondSucessLabel
            // 
            this.secondSucessLabel.AutoSize = true;
            this.secondSucessLabel.BackColor = System.Drawing.Color.Transparent;
            this.secondSucessLabel.Font = new System.Drawing.Font("맑은 고딕", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.secondSucessLabel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.secondSucessLabel.Location = new System.Drawing.Point(130, 225);
            this.secondSucessLabel.Name = "secondSucessLabel";
            this.secondSucessLabel.Size = new System.Drawing.Size(58, 38);
            this.secondSucessLabel.TabIndex = 43;
            this.secondSucessLabel.Text = "x 0";
            this.secondSucessLabel.Click += new System.EventHandler(this.label4_Click_1);
            // 
            // reset
            // 
            this.reset.Cursor = System.Windows.Forms.Cursors.Hand;
            this.reset.Font = new System.Drawing.Font("돋움", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.reset.Location = new System.Drawing.Point(431, 526);
            this.reset.Name = "reset";
            this.reset.Size = new System.Drawing.Size(130, 50);
            this.reset.TabIndex = 44;
            this.reset.Text = "초기화";
            this.reset.UseVisualStyleBackColor = true;
            this.reset.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1032, 603);
            this.Controls.Add(this.reset);
            this.Controls.Add(this.secondSucessLabel);
            this.Controls.Add(this.thirdSucessLabel);
            this.Controls.Add(this.firstSucessLabel);
            this.Controls.Add(this.FirstBtn0);
            this.Controls.Add(this.problabel);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.thirdDrilling);
            this.Controls.Add(this.ThirdBtn9);
            this.Controls.Add(this.ThirdBtn2);
            this.Controls.Add(this.ThirdBtn1);
            this.Controls.Add(this.ThirdBtn3);
            this.Controls.Add(this.ThirdBtn4);
            this.Controls.Add(this.ThirdBtn5);
            this.Controls.Add(this.ThirdBtn6);
            this.Controls.Add(this.ThirdBtn7);
            this.Controls.Add(this.ThirdBtn8);
            this.Controls.Add(this.ThirdBtn0);
            this.Controls.Add(this.button36);
            this.Controls.Add(this.secondDrilling);
            this.Controls.Add(this.SecondBtn9);
            this.Controls.Add(this.SecondBtn2);
            this.Controls.Add(this.SecondBtn1);
            this.Controls.Add(this.SecondBtn3);
            this.Controls.Add(this.SecondBtn4);
            this.Controls.Add(this.SecondBtn5);
            this.Controls.Add(this.SecondBtn6);
            this.Controls.Add(this.SecondBtn7);
            this.Controls.Add(this.SecondBtn8);
            this.Controls.Add(this.SecondBtn0);
            this.Controls.Add(this.FirstBtn3);
            this.Controls.Add(this.FirstBtn2);
            this.Controls.Add(this.FirstBtn4);
            this.Controls.Add(this.FirstBtn5);
            this.Controls.Add(this.FirstBtn6);
            this.Controls.Add(this.FirstBtn7);
            this.Controls.Add(this.FirstBtn8);
            this.Controls.Add(this.FirstBtn9);
            this.Controls.Add(this.FirstBtn1);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.FirstDrilling);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button FirstDrilling;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button FirstBtn1;
        private System.Windows.Forms.Button FirstBtn9;
        private System.Windows.Forms.Button FirstBtn8;
        private System.Windows.Forms.Button FirstBtn7;
        private System.Windows.Forms.Button FirstBtn6;
        private System.Windows.Forms.Button FirstBtn5;
        private System.Windows.Forms.Button FirstBtn4;
        private System.Windows.Forms.Button FirstBtn2;
        private System.Windows.Forms.Button FirstBtn3;
        private System.Windows.Forms.Button SecondBtn9;
        private System.Windows.Forms.Button SecondBtn2;
        private System.Windows.Forms.Button SecondBtn1;
        private System.Windows.Forms.Button SecondBtn3;
        private System.Windows.Forms.Button SecondBtn4;
        private System.Windows.Forms.Button SecondBtn5;
        private System.Windows.Forms.Button SecondBtn6;
        private System.Windows.Forms.Button SecondBtn7;
        private System.Windows.Forms.Button SecondBtn8;
        private System.Windows.Forms.Button SecondBtn0;
        private System.Windows.Forms.Button secondDrilling;
        private System.Windows.Forms.Button thirdDrilling;
        private System.Windows.Forms.Button ThirdBtn9;
        private System.Windows.Forms.Button ThirdBtn2;
        private System.Windows.Forms.Button ThirdBtn1;
        private System.Windows.Forms.Button ThirdBtn3;
        private System.Windows.Forms.Button ThirdBtn4;
        private System.Windows.Forms.Button ThirdBtn5;
        private System.Windows.Forms.Button ThirdBtn6;
        private System.Windows.Forms.Button ThirdBtn7;
        private System.Windows.Forms.Button ThirdBtn8;
        private System.Windows.Forms.Button ThirdBtn0;
        private System.Windows.Forms.Button button36;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label problabel;
        private System.Windows.Forms.Button FirstBtn0;
        private System.Windows.Forms.Label firstSucessLabel;
        private System.Windows.Forms.Label thirdSucessLabel;
        private System.Windows.Forms.Label secondSucessLabel;
        private System.Windows.Forms.Button reset;
    }
}

