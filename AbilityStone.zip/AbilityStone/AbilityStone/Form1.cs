﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AbilityStone
{
    public partial class Form1 : Form
    {
        public int drillProb = 75;
        public Random random = new Random();

        public int firstOrder = 0;
        public int secondOrder = 0;
        public int thirdOrder = 0;

        public int firstSucess = 0;
        public int secondSucess = 0;
        public int thirdSucess = 0;

        public Button[] firstBtns;
        public Button[] secondBtns;
        public Button[] thirdBtns;

        public Form1()
        {
            InitializeComponent();
            firstBtns = new Button[] { FirstBtn0, FirstBtn1, FirstBtn2, FirstBtn3, FirstBtn4, FirstBtn5,
                FirstBtn6, FirstBtn7, FirstBtn8, FirstBtn9};

            secondBtns = new Button[] { SecondBtn0, SecondBtn1, SecondBtn2, SecondBtn3, SecondBtn4, SecondBtn5,
                SecondBtn6, SecondBtn7, SecondBtn8, SecondBtn9};

            thirdBtns = new Button[] { ThirdBtn0, ThirdBtn1, ThirdBtn2, ThirdBtn3, ThirdBtn4, ThirdBtn5,
                ThirdBtn6, ThirdBtn7, ThirdBtn8, ThirdBtn9};
        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void 세공_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void FirstDrilling_Click(object sender, EventArgs e)
        {
            if(firstOrder<10)
            {
                int randomNumber = random.Next(100);

                if (randomNumber < drillProb)
                {
                    firstSucess += 1;
                    firstSucessLabel.Text = "x" + firstSucess;
                    Sucess();
                    firstBtns[firstOrder].BackColor = Color.Blue;
                }
                else
                {
                    Fail();
                    firstBtns[firstOrder].BackColor = Color.Red;
                }
                firstOrder++;

                if(firstOrder == 10)
                {
                    FirstDrilling.BackColor = Color.White;
                    FirstDrilling.Enabled = false;
                    FirstDrilling.Text = "세공완료";
                }
                problabel.Text = drillProb.ToString() + "%";
            }
        }

        private void SecondDrilling_Click(object sender, EventArgs e)
        {
            if(secondOrder < 10)
            {
                int randomNumber = random.Next(100);

                if (randomNumber < drillProb)
                {
                    secondSucess += 1;
                    secondSucessLabel.Text = "x" + secondSucess;
                    Sucess();
                    secondBtns[secondOrder].BackColor = Color.Blue;
                }
                else
                {
                    Fail();
                    secondBtns[secondOrder].BackColor = Color.Red;
                }
                secondOrder++;

                if (secondOrder == 10)
                {
                    secondDrilling.BackColor = Color.White;
                    secondDrilling.Enabled = false;
                    secondDrilling.Text = "세공완료";
                }
                problabel.Text = drillProb.ToString() + "%";
            }
        }

        private void ThirdDrilling_Click(object sender, EventArgs e)
        {
            if (thirdOrder < 10)
            {
                int randomNumber = random.Next(100);

                if (randomNumber < drillProb)
                {
                    thirdSucess += 1;
                    thirdSucessLabel.Text = "x" + thirdSucess;
                    Sucess();
                    thirdBtns[thirdOrder].BackColor = Color.Blue;
                }
                else
                {
                    Fail();
                    thirdBtns[thirdOrder].BackColor = Color.Red;
                }
                thirdOrder++;

                if (thirdOrder == 10)
                {
                    thirdDrilling.BackColor = Color.White;
                    thirdDrilling.Enabled = false;
                    thirdDrilling.Text = "세공완료";
                }
                problabel.Text = drillProb.ToString() + "%";
            }
        }

        private void FirstBtn0_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click_1(object sender, EventArgs e)
        {

        }

        public void Sucess()
        {
            if (drillProb != 25)
            {
                drillProb -= 10;
                problabel.ForeColor = Color.Black;

                if (drillProb == 25)
                {
                    problabel.ForeColor = Color.Red;
                }
            }
            else
            {
                problabel.ForeColor = Color.Red;
            }
        }
        public void Fail()
        {
            if (drillProb != 75)
            {
                drillProb += 10;
                problabel.ForeColor = Color.Black;
                
                if(drillProb == 75)
                {
                    problabel.ForeColor = Color.Blue;
                }
            }
            else
            {
                problabel.ForeColor = Color.Blue;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            drillProb = 75;
            problabel.Text = drillProb + "%";

            firstOrder = 0;
            secondOrder = 0;
            thirdOrder = 0;

            firstSucess = 0;
            secondSucess = 0;
            thirdSucess = 0;

            firstSucessLabel.Text = "x" + firstSucess;
            secondSucessLabel.Text = "x" + secondSucess;
            thirdSucessLabel.Text = "x" + thirdSucess;

            foreach (Button btn in firstBtns)
            {
                btn.BackColor = Color.Black;
            }
            foreach (Button btn in secondBtns)
            {
                btn.BackColor = Color.Black;
            }
            foreach (Button btn in thirdBtns)
            {
                btn.BackColor = Color.Black;
            }

            FirstDrilling.Enabled = true;
            FirstDrilling.BackColor = Color.FromArgb(224, 224, 224);
            FirstDrilling.Text = "세공";

            secondDrilling.Enabled = true;
            secondDrilling.BackColor = Color.FromArgb(224, 224, 224);
            secondDrilling.Text = "세공";

            thirdDrilling.Enabled = true;
            thirdDrilling.BackColor = Color.FromArgb(224, 224, 224);
            thirdDrilling.Text = "세공";
        }
    }
}
